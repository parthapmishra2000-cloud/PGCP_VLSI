`timescale 1ns/1ps

module  fsm_1_tb;
reg clk, rst, en;
reg [7:0] tx_data;
wire dout;

fsm_1 f1 (
    .tx_data(tx_data),
    .clk(clk),
    .rst(rst),
    .en(en),
    .dout(dout)
);


//Generate clock. 
always #5 clk = ~clk;
initial begin
    $dumpfile("Q1.vcd");
    $dumpvars(0, fsm_1_tb);

    $monitor("Time: %t, rst: %b, en: %b, tx_data: %b, dout: %b", $time, rst, en, tx_data, dout);
    clk = 0; rst = 1; en = 0;
    //Testcase 1
    tx_data = 8'b10101010; 
    #10 rst = 0;

    #10 en = 1;

    #100;
    //Testcase 2
    tx_data = 8'b11001100;
    #80; 
    en = 0;
    #20;
end

    
endmodule
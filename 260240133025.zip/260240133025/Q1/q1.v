module fsm_1 (
    input [7:0]tx_data,
    input clk,rst,en,
    output reg dout
);

reg [2:0] state;
wire [2:0] next;

assign next = (state == 7) ? 0 : state + 1;

always@(posedge clk or posedge rst)
begin 
    if(rst)
        state <= 0;
    else if (en == 1) 
        state <= next;
    else
        state <= state;
end

always@(*) ///Output Logic
begin
    dout = tx_data[state];
end

endmodule


`timescale 1ns/1ps

module piso_tb;

reg clk, load;
reg i0,i1,i2,i3,i4,i5,i6,i7;
wire [7:0] out;

piso p1(
    .clk(clk),
    .load(load),
    .i0(i0),
    .i1(i1),
    .i2(i2),
    .i3(i3),
    .i4(i4),
    .i5(i5),
    .i6(i6),
    .i7(i7),
    .s_out(out)
);

always #5 clk = ~clk;

initial begin
    $dumpfile("Q2.vcd");
    $dumpvars(0, piso_tb);
    $monitor("Time: %t, load: %b, s_out: %b", $time, load, out);
    clk = 0;
    load = 0;
    i0 = 1; i1 = 1;
    i2 = 1; i3 = 0; 
    i4 = 1; i5 = 0; 
    i6 = 1; i7 = 1; // 11101011

    #10 load = 1;
    #10 load = 0;
    //Delay
    #80;

    // Testcase 2
    i0 = 0; i1 = 1; 
    i2 = 1; i3 = 0; 
    i4 = 0; i5 = 1; 
    i6 = 0; i7 = 0; // 01100100

    #10 load = 1;
    #10 load = 0;

    #80;
    $finish;
end


endmodule

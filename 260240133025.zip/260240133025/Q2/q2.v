`timescale 1ns/1ps

module piso (
    input clk, load,
    input i0,i1,i2,i3,i4,i5,i6,i7,
    output reg [7:0] s_out
);
 
    always @(posedge clk) begin
        if (load) begin
            s_out[0] <= i0;
            s_out[1] <= i1;
            s_out[2] <= i2;
            s_out[3] <= i3;
            s_out[4] <= i4;
            s_out[5] <= i5;
            s_out[6] <= i6;
            s_out[7] <= i7;
        end 
        else begin
            s_out[0] <= s_out[1];
            s_out[1] <= s_out[2];
            s_out[2] <= s_out[3];
            s_out[3] <= s_out[4];
            s_out[4] <= s_out[5];
            s_out[5] <= s_out[6];
            s_out[6] <= s_out[7];
            s_out[7] <= 0;
        end
    end

endmodule





























